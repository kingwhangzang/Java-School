class EventTestMain 
{
	public static void main(String[] args) 
	{
		//EventTestType1 t1 = new  EventTestType1("Type 1 Event");
		//EventTestType2 t2 = new EventTestType2("Type 2 Event");
		//EventTestType3 t3 = new EventTestType3("Type 3 Event");
		//EventTestType4 t4 = new EventTestType4("Type 4 Event");
		EventTestType5 t5 = new EventTestType5("Type 5 Event");
	}
}
