public class TextEventTestMain {
    public static void main(String[] args) {
        TextEventTest textEventTest = new TextEventTest("Text Event Test");
    }
}