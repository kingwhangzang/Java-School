class ButtonEventMain1
{
	public static void main(String[] args) 
	{
		ButtonEventType1 t1 = new ButtonEventType1("ButtonEventType1");
	}
}
