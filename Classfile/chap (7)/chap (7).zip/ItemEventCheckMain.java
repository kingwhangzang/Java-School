public class ItemEventCheckMain {
    public static void main(String[] args) {
        ItemEventCheck itemEventCheck = new ItemEventCheck("Item Event Check");
    }
}