import javax.swing.*;

class ButtonEventType3Main 
{
	public static void main(String[] args) 
	{
		JFrame f = new JFrame();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.add(new ButtonEventType3());
		f.setSize(300,300);
		f.setVisible(true);
		}
}
